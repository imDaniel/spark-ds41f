// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* mhc_project_streams_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_mhc_project_streams(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_mhc_project_streams(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[15];
  void* stack_ffi_any = stack;
  if (!((num_args == 11))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "mhc_project_streams: num_args should be 11", (long long)(num_args), (long long)(11));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_project_streams: args pointer is NULL");
    return -1;
  }
  int32_t X_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((X_handle_type_index == 0) || (X_handle_type_index == 4)) || (X_handle_type_index == 7)) || (64 <= X_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input X expected pointer or tensor handle");
    return -1;
  }
  int32_t R_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((R_handle_type_index == 0) || (R_handle_type_index == 4)) || (R_handle_type_index == 7)) || (64 <= R_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R expected pointer or tensor handle");
    return -1;
  }
  int32_t post_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((post_handle_type_index == 0) || (post_handle_type_index == 4)) || (post_handle_type_index == 7)) || (64 <= post_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input post expected pointer or tensor handle");
    return -1;
  }
  int32_t comb_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((comb_handle_type_index == 0) || (comb_handle_type_index == 4)) || (comb_handle_type_index == 7)) || (64 <= comb_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb expected pointer or tensor handle");
    return -1;
  }
  int32_t pre_in_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((pre_in_handle_type_index == 0) || (pre_in_handle_type_index == 4)) || (pre_in_handle_type_index == 7)) || (64 <= pre_in_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input pre_in expected pointer or tensor handle");
    return -1;
  }
  int32_t Fn_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((Fn_handle_type_index == 0) || (Fn_handle_type_index == 4)) || (Fn_handle_type_index == 7)) || (64 <= Fn_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input Fn expected pointer or tensor handle");
    return -1;
  }
  int32_t R_out_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((R_out_handle_type_index == 0) || (R_out_handle_type_index == 4)) || (R_out_handle_type_index == 7)) || (64 <= R_out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R_out expected pointer or tensor handle");
    return -1;
  }
  int32_t P_handle_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((((P_handle_type_index == 0) || (P_handle_type_index == 4)) || (P_handle_type_index == 7)) || (64 <= P_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input P expected pointer or tensor handle");
    return -1;
  }
  int32_t S_handle_type_index = (((TVMFFIAny*)args)[8].type_index);
  if (!(((((S_handle_type_index == 0) || (S_handle_type_index == 4)) || (S_handle_type_index == 7)) || (64 <= S_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input S expected pointer or tensor handle");
    return -1;
  }
  int32_t C_handle_type_index = (((TVMFFIAny*)args)[9].type_index);
  if (!(((((C_handle_type_index == 0) || (C_handle_type_index == 4)) || (C_handle_type_index == 7)) || (64 <= C_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input C expected pointer or tensor handle");
    return -1;
  }
  int32_t Q_handle_type_index = (((TVMFFIAny*)args)[10].type_index);
  if (!(((((Q_handle_type_index == 0) || (Q_handle_type_index == 4)) || (Q_handle_type_index == 7)) || (64 <= Q_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input Q expected pointer or tensor handle");
    return -1;
  }
  void* X_handle = ((X_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* R_handle = ((R_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* post_handle = ((post_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* comb_handle = ((comb_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* pre_in_handle = ((pre_in_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* Fn_handle = ((Fn_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* R_out_handle = ((R_out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  void* P_handle = ((P_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[7].v_ptr) + 24)) : (((TVMFFIAny*)args)[7].v_ptr));
  void* S_handle = ((S_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[8].v_ptr) + 24)) : (((TVMFFIAny*)args)[8].v_ptr));
  void* C_handle = ((C_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[9].v_ptr) + 24)) : (((TVMFFIAny*)args)[9].v_ptr));
  void* Q_handle = ((Q_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[10].v_ptr) + 24)) : (((TVMFFIAny*)args)[10].v_ptr));
  bool mhc_project_streams_X_is_null = (X_handle == NULL);
  bool mhc_project_streams_R_is_null = (R_handle == NULL);
  if (!(!mhc_project_streams_R_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_project_streams.R is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_project_streams_post_is_null = (post_handle == NULL);
  bool mhc_project_streams_comb_is_null = (comb_handle == NULL);
  bool mhc_project_streams_pre_in_is_null = (pre_in_handle == NULL);
  if (!(!mhc_project_streams_pre_in_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_project_streams.pre_in is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_project_streams_Fn_is_null = (Fn_handle == NULL);
  if (!(!mhc_project_streams_Fn_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_project_streams.Fn is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_project_streams_R_out_is_null = (R_out_handle == NULL);
  bool mhc_project_streams_P_is_null = (P_handle == NULL);
  if (!(!mhc_project_streams_P_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_project_streams.P is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_project_streams_S_is_null = (S_handle == NULL);
  if (!(!mhc_project_streams_S_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_project_streams.S is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_project_streams_C_is_null = (C_handle == NULL);
  if (!(!mhc_project_streams_C_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_project_streams.C is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_project_streams_Q_is_null = (Q_handle == NULL);
  if (!(!mhc_project_streams_Q_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_project_streams.Q is expected to have non-NULL pointer");
    return -1;
  }
  void* condval;
  if (!mhc_project_streams_X_is_null) {
    condval = (((DLTensor*)X_handle)[0].shape);
  } else {
    uint64_t v_ = (uint64_t)0;
    condval = (*(void* *)(&(v_)));
  }
  void* mhc_project_streams_X_shape = condval;
  void* mhc_project_streams_R_shape = (((DLTensor*)R_handle)[0].shape);
  void* condval_1;
  if (!mhc_project_streams_post_is_null) {
    condval_1 = (((DLTensor*)post_handle)[0].shape);
  } else {
    uint64_t v__1 = (uint64_t)0;
    condval_1 = (*(void* *)(&(v__1)));
  }
  void* mhc_project_streams_post_shape = condval_1;
  void* condval_2;
  if (!mhc_project_streams_comb_is_null) {
    condval_2 = (((DLTensor*)comb_handle)[0].shape);
  } else {
    uint64_t v__2 = (uint64_t)0;
    condval_2 = (*(void* *)(&(v__2)));
  }
  void* mhc_project_streams_comb_shape = condval_2;
  void* mhc_project_streams_pre_in_shape = (((DLTensor*)pre_in_handle)[0].shape);
  void* mhc_project_streams_Fn_shape = (((DLTensor*)Fn_handle)[0].shape);
  void* condval_3;
  if (!mhc_project_streams_R_out_is_null) {
    condval_3 = (((DLTensor*)R_out_handle)[0].shape);
  } else {
    uint64_t v__3 = (uint64_t)0;
    condval_3 = (*(void* *)(&(v__3)));
  }
  void* mhc_project_streams_R_out_shape = condval_3;
  void* mhc_project_streams_P_shape = (((DLTensor*)P_handle)[0].shape);
  void* mhc_project_streams_S_shape = (((DLTensor*)S_handle)[0].shape);
  void* mhc_project_streams_C_shape = (((DLTensor*)C_handle)[0].shape);
  void* mhc_project_streams_Q_shape = (((DLTensor*)Q_handle)[0].shape);
  if (!((mhc_project_streams_X_is_null || ((((DLTensor*)X_handle)[0].ndim) == 3)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input X ndim mismatch, expected 3");
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable M requires at least one non-null buffer among: mhc_project_streams.X, mhc_project_streams.R, mhc_project_streams.post, mhc_project_streams.comb, mhc_project_streams.pre_in, mhc_project_streams.R_out, mhc_project_streams.P, mhc_project_streams.S, mhc_project_streams.C, mhc_project_streams.Q");
    return -1;
  }
  int32_t condval_4;
  if (!mhc_project_streams_X_is_null) {
    condval_4 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_4 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  int32_t M = condval_4;
  void* condval_5;
  if (!mhc_project_streams_X_is_null) {
    condval_5 = (((DLTensor*)X_handle)[0].strides);
  } else {
    uint64_t v__4 = (uint64_t)0;
    condval_5 = (*(void* *)(&(v__4)));
  }
  void* mhc_project_streams_X_strides = condval_5;
  int32_t condval_6;
  if (!mhc_project_streams_X_is_null) {
    condval_6 = (((DLTensor*)X_handle)[0].device.device_id);
  } else {
    condval_6 = 0;
  }
  int32_t dev_id = condval_6;
  void* condval_7;
  if (!mhc_project_streams_X_is_null) {
    condval_7 = (((DLTensor*)X_handle)[0].data);
  } else {
    uint64_t v__5 = (uint64_t)0;
    condval_7 = (*(void* *)(&(v__5)));
  }
  void* X = condval_7;
  if (!(((((DLTensor*)R_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input R ndim mismatch, expected 2", (long long)((((DLTensor*)R_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_project_streams_R_strides = (((DLTensor*)R_handle)[0].strides);
  void* R = (((DLTensor*)R_handle)[0].data);
  if (!((mhc_project_streams_post_is_null || ((((DLTensor*)post_handle)[0].ndim) == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input post ndim mismatch, expected 2");
    return -1;
  }
  void* condval_8;
  if (!mhc_project_streams_post_is_null) {
    condval_8 = (((DLTensor*)post_handle)[0].strides);
  } else {
    uint64_t v__6 = (uint64_t)0;
    condval_8 = (*(void* *)(&(v__6)));
  }
  void* mhc_project_streams_post_strides = condval_8;
  void* condval_9;
  if (!mhc_project_streams_post_is_null) {
    condval_9 = (((DLTensor*)post_handle)[0].data);
  } else {
    uint64_t v__7 = (uint64_t)0;
    condval_9 = (*(void* *)(&(v__7)));
  }
  void* post = condval_9;
  if (!((mhc_project_streams_comb_is_null || ((((DLTensor*)comb_handle)[0].ndim) == 3)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb ndim mismatch, expected 3");
    return -1;
  }
  void* condval_10;
  if (!mhc_project_streams_comb_is_null) {
    condval_10 = (((DLTensor*)comb_handle)[0].strides);
  } else {
    uint64_t v__8 = (uint64_t)0;
    condval_10 = (*(void* *)(&(v__8)));
  }
  void* mhc_project_streams_comb_strides = condval_10;
  void* condval_11;
  if (!mhc_project_streams_comb_is_null) {
    condval_11 = (((DLTensor*)comb_handle)[0].data);
  } else {
    uint64_t v__9 = (uint64_t)0;
    condval_11 = (*(void* *)(&(v__9)));
  }
  void* comb = condval_11;
  if (!(((((DLTensor*)pre_in_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input pre_in ndim mismatch, expected 2", (long long)((((DLTensor*)pre_in_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_project_streams_pre_in_strides = (((DLTensor*)pre_in_handle)[0].strides);
  void* pre_in = (((DLTensor*)pre_in_handle)[0].data);
  if (!(((((DLTensor*)Fn_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Fn ndim mismatch, expected 2", (long long)((((DLTensor*)Fn_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_project_streams_Fn_strides = (((DLTensor*)Fn_handle)[0].strides);
  void* Fn = (((DLTensor*)Fn_handle)[0].data);
  if (!((mhc_project_streams_R_out_is_null || ((((DLTensor*)R_out_handle)[0].ndim) == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R_out ndim mismatch, expected 2");
    return -1;
  }
  void* condval_12;
  if (!mhc_project_streams_R_out_is_null) {
    condval_12 = (((DLTensor*)R_out_handle)[0].strides);
  } else {
    uint64_t v__10 = (uint64_t)0;
    condval_12 = (*(void* *)(&(v__10)));
  }
  void* mhc_project_streams_R_out_strides = condval_12;
  void* condval_13;
  if (!mhc_project_streams_R_out_is_null) {
    condval_13 = (((DLTensor*)R_out_handle)[0].data);
  } else {
    uint64_t v__11 = (uint64_t)0;
    condval_13 = (*(void* *)(&(v__11)));
  }
  void* R_out = condval_13;
  if (!(((((DLTensor*)P_handle)[0].ndim) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input P ndim mismatch, expected 4", (long long)((((DLTensor*)P_handle)[0].ndim)), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_project_streams_P_strides = (((DLTensor*)P_handle)[0].strides);
  void* P = (((DLTensor*)P_handle)[0].data);
  if (!(((((DLTensor*)S_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input S ndim mismatch, expected 3", (long long)((((DLTensor*)S_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_project_streams_S_strides = (((DLTensor*)S_handle)[0].strides);
  void* S = (((DLTensor*)S_handle)[0].data);
  if (!(((((DLTensor*)C_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input C ndim mismatch, expected 2", (long long)((((DLTensor*)C_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_project_streams_C_strides = (((DLTensor*)C_handle)[0].strides);
  void* C = (((DLTensor*)C_handle)[0].data);
  if (!(((((DLTensor*)Q_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Q ndim mismatch, expected 2", (long long)((((DLTensor*)Q_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_project_streams_Q_strides = (((DLTensor*)Q_handle)[0].strides);
  void* Q = (((DLTensor*)Q_handle)[0].data);
  uint8_t condval_14;
  if (!mhc_project_streams_X_is_null) {
    condval_14 = (((DLTensor*)X_handle)[0].dtype.code);
  } else {
    condval_14 = (uint8_t)4;
  }
  uint8_t condval_15;
  if (!mhc_project_streams_X_is_null) {
    condval_15 = (((DLTensor*)X_handle)[0].dtype.bits);
  } else {
    condval_15 = (uint8_t)16;
  }
  uint16_t condval_16;
  if (!mhc_project_streams_X_is_null) {
    condval_16 = (((DLTensor*)X_handle)[0].dtype.lanes);
  } else {
    condval_16 = (uint16_t)1;
  }
  if (!((mhc_project_streams_X_is_null || (((condval_14 == (uint8_t)4) && (condval_15 == (uint8_t)16)) && (condval_16 == (uint16_t)1))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input X dtype mismatch, expected bfloat16");
    return -1;
  }
  int32_t condval_17;
  if (!mhc_project_streams_X_is_null) {
    condval_17 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[0]);
  } else {
    condval_17 = 0;
  }
  if (!((mhc_project_streams_X_is_null || (condval_17 == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input X shape[0] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_18;
  if (!mhc_project_streams_X_is_null) {
    condval_18 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[2]);
  } else {
    condval_18 = 0;
  }
  if (!((mhc_project_streams_X_is_null || (condval_18 == 5120)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input X shape[2] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_19;
  if ((mhc_project_streams_X_strides == NULL)) {
    condval_19 = 1;
  } else {
    condval_19 = ((int32_t)((int64_t*)mhc_project_streams_X_strides)[2]);
  }
  if (!((mhc_project_streams_X_is_null || (condval_19 == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input X strides[2] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_20;
  if ((mhc_project_streams_X_strides == NULL)) {
    condval_20 = 1;
  } else {
    condval_20 = ((int32_t)((int64_t*)mhc_project_streams_X_strides)[1]);
  }
  if (!(((mhc_project_streams_X_is_null || (condval_20 == 5120)) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input X strides[1] violates packed ABI constraint");
    return -1;
  }
  uint64_t condval_21;
  if (!mhc_project_streams_X_is_null) {
    condval_21 = (((DLTensor*)X_handle)[0].byte_offset);
  } else {
    condval_21 = (uint64_t)0;
  }
  if (!((mhc_project_streams_X_is_null || ((uint64_t)0 == condval_21)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input X byte_offset violates packed ABI constraint");
    return -1;
  }
  int32_t condval_22;
  if (!mhc_project_streams_X_is_null) {
    condval_22 = (((DLTensor*)X_handle)[0].device.device_type);
  } else {
    condval_22 = 0;
  }
  if (!((mhc_project_streams_X_is_null || (condval_22 == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input X device_type mismatch, expected cuda");
    return -1;
  }
  if (!(((mhc_project_streams_X_is_null || (M == 0)) || !(X == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input X data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)R_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)R_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)R_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R dtype mismatch, expected bfloat16");
    return -1;
  }
  int32_t condval_23;
  if (!mhc_project_streams_X_is_null) {
    condval_23 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_23 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  if (!((condval_23 == ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0])))) {
    int32_t condval_24;
    if (!mhc_project_streams_X_is_null) {
      condval_24 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
    } else {
      condval_24 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input R shape[0] violates packed ABI constraint", (long long)(condval_24), (long long)(((int32_t)((int64_t*)mhc_project_streams_R_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_project_streams_R_shape)[1]) == 20480))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input R shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_project_streams_R_shape)[1])), (long long)(20480));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_25;
  if ((mhc_project_streams_R_strides == NULL)) {
    condval_25 = 1;
  } else {
    condval_25 = ((int32_t)((int64_t*)mhc_project_streams_R_strides)[1]);
  }
  if (!((condval_25 == 1))) {
    int32_t condval_26;
    if ((mhc_project_streams_R_strides == NULL)) {
      condval_26 = 1;
    } else {
      condval_26 = ((int32_t)((int64_t*)mhc_project_streams_R_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input R strides[1] violates packed ABI constraint", (long long)(condval_26), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_27;
  if ((mhc_project_streams_R_strides == NULL)) {
    condval_27 = 1;
  } else {
    condval_27 = ((int32_t)((int64_t*)mhc_project_streams_R_strides)[0]);
  }
  if (!(((condval_27 == 20480) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)R_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input R byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)R_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_28;
  if (!mhc_project_streams_X_is_null) {
    condval_28 = (((DLTensor*)X_handle)[0].device.device_id);
  } else {
    condval_28 = 0;
  }
  if (!(((((DLTensor*)R_handle)[0].device.device_id) == condval_28))) {
    int32_t condval_29;
    if (!mhc_project_streams_X_is_null) {
      condval_29 = (((DLTensor*)X_handle)[0].device.device_id);
    } else {
      condval_29 = 0;
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input R device_id violates packed ABI constraint", (long long)((((DLTensor*)R_handle)[0].device.device_id)), (long long)(condval_29));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)R_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input R device_type mismatch, expected cuda", (long long)((((DLTensor*)R_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(R == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R data pointer is NULL");
    return -1;
  }
  uint8_t condval_30;
  if (!mhc_project_streams_post_is_null) {
    condval_30 = (((DLTensor*)post_handle)[0].dtype.code);
  } else {
    condval_30 = (uint8_t)2;
  }
  uint8_t condval_31;
  if (!mhc_project_streams_post_is_null) {
    condval_31 = (((DLTensor*)post_handle)[0].dtype.bits);
  } else {
    condval_31 = (uint8_t)32;
  }
  uint16_t condval_32;
  if (!mhc_project_streams_post_is_null) {
    condval_32 = (((DLTensor*)post_handle)[0].dtype.lanes);
  } else {
    condval_32 = (uint16_t)1;
  }
  if (!((mhc_project_streams_post_is_null || (((condval_30 == (uint8_t)2) && (condval_31 == (uint8_t)32)) && (condval_32 == (uint16_t)1))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input post dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_33;
  if (!mhc_project_streams_X_is_null) {
    condval_33 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_33 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  int32_t condval_34;
  if (!mhc_project_streams_post_is_null) {
    condval_34 = ((int32_t)((int64_t*)mhc_project_streams_post_shape)[0]);
  } else {
    condval_34 = 0;
  }
  if (!((mhc_project_streams_post_is_null || (condval_33 == condval_34)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input post shape[0] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_35;
  if (!mhc_project_streams_post_is_null) {
    condval_35 = ((int32_t)((int64_t*)mhc_project_streams_post_shape)[1]);
  } else {
    condval_35 = 0;
  }
  if (!((mhc_project_streams_post_is_null || (condval_35 == 4)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input post shape[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_36;
  if ((mhc_project_streams_post_strides == NULL)) {
    condval_36 = 1;
  } else {
    condval_36 = ((int32_t)((int64_t*)mhc_project_streams_post_strides)[1]);
  }
  if (!((mhc_project_streams_post_is_null || (condval_36 == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input post strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_37;
  if ((mhc_project_streams_post_strides == NULL)) {
    condval_37 = 1;
  } else {
    condval_37 = ((int32_t)((int64_t*)mhc_project_streams_post_strides)[0]);
  }
  if (!(((mhc_project_streams_post_is_null || (condval_37 == 4)) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input post strides[0] violates packed ABI constraint");
    return -1;
  }
  uint64_t condval_38;
  if (!mhc_project_streams_post_is_null) {
    condval_38 = (((DLTensor*)post_handle)[0].byte_offset);
  } else {
    condval_38 = (uint64_t)0;
  }
  if (!((mhc_project_streams_post_is_null || ((uint64_t)0 == condval_38)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input post byte_offset violates packed ABI constraint");
    return -1;
  }
  int32_t condval_39;
  if (!mhc_project_streams_post_is_null) {
    condval_39 = (((DLTensor*)post_handle)[0].device.device_id);
  } else {
    condval_39 = 0;
  }
  int32_t condval_40;
  if (!mhc_project_streams_X_is_null) {
    condval_40 = (((DLTensor*)X_handle)[0].device.device_id);
  } else {
    condval_40 = 0;
  }
  if (!((mhc_project_streams_post_is_null || (condval_39 == condval_40)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input post device_id violates packed ABI constraint");
    return -1;
  }
  int32_t condval_41;
  if (!mhc_project_streams_post_is_null) {
    condval_41 = (((DLTensor*)post_handle)[0].device.device_type);
  } else {
    condval_41 = 0;
  }
  if (!((mhc_project_streams_post_is_null || (condval_41 == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input post device_type mismatch, expected cuda");
    return -1;
  }
  if (!(((mhc_project_streams_post_is_null || (M == 0)) || !(post == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input post data pointer is NULL");
    return -1;
  }
  uint8_t condval_42;
  if (!mhc_project_streams_comb_is_null) {
    condval_42 = (((DLTensor*)comb_handle)[0].dtype.code);
  } else {
    condval_42 = (uint8_t)2;
  }
  uint8_t condval_43;
  if (!mhc_project_streams_comb_is_null) {
    condval_43 = (((DLTensor*)comb_handle)[0].dtype.bits);
  } else {
    condval_43 = (uint8_t)32;
  }
  uint16_t condval_44;
  if (!mhc_project_streams_comb_is_null) {
    condval_44 = (((DLTensor*)comb_handle)[0].dtype.lanes);
  } else {
    condval_44 = (uint16_t)1;
  }
  if (!((mhc_project_streams_comb_is_null || (((condval_42 == (uint8_t)2) && (condval_43 == (uint8_t)32)) && (condval_44 == (uint16_t)1))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_45;
  if (!mhc_project_streams_X_is_null) {
    condval_45 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_45 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  int32_t condval_46;
  if (!mhc_project_streams_comb_is_null) {
    condval_46 = ((int32_t)((int64_t*)mhc_project_streams_comb_shape)[0]);
  } else {
    condval_46 = 0;
  }
  if (!((mhc_project_streams_comb_is_null || (condval_45 == condval_46)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb shape[0] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_47;
  if (!mhc_project_streams_comb_is_null) {
    condval_47 = ((int32_t)((int64_t*)mhc_project_streams_comb_shape)[1]);
  } else {
    condval_47 = 0;
  }
  if (!((mhc_project_streams_comb_is_null || (condval_47 == 4)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb shape[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_48;
  if (!mhc_project_streams_comb_is_null) {
    condval_48 = ((int32_t)((int64_t*)mhc_project_streams_comb_shape)[2]);
  } else {
    condval_48 = 0;
  }
  if (!((mhc_project_streams_comb_is_null || (condval_48 == 4)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb shape[2] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_49;
  if ((mhc_project_streams_comb_strides == NULL)) {
    condval_49 = 1;
  } else {
    condval_49 = ((int32_t)((int64_t*)mhc_project_streams_comb_strides)[2]);
  }
  if (!((mhc_project_streams_comb_is_null || (condval_49 == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb strides[2] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_50;
  if ((mhc_project_streams_comb_strides == NULL)) {
    condval_50 = 1;
  } else {
    condval_50 = ((int32_t)((int64_t*)mhc_project_streams_comb_strides)[1]);
  }
  if (!((mhc_project_streams_comb_is_null || (condval_50 == 4)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_51;
  if ((mhc_project_streams_comb_strides == NULL)) {
    condval_51 = 1;
  } else {
    condval_51 = ((int32_t)((int64_t*)mhc_project_streams_comb_strides)[0]);
  }
  if (!(((mhc_project_streams_comb_is_null || (condval_51 == 16)) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb strides[0] violates packed ABI constraint");
    return -1;
  }
  uint64_t condval_52;
  if (!mhc_project_streams_comb_is_null) {
    condval_52 = (((DLTensor*)comb_handle)[0].byte_offset);
  } else {
    condval_52 = (uint64_t)0;
  }
  if (!((mhc_project_streams_comb_is_null || ((uint64_t)0 == condval_52)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb byte_offset violates packed ABI constraint");
    return -1;
  }
  int32_t condval_53;
  if (!mhc_project_streams_comb_is_null) {
    condval_53 = (((DLTensor*)comb_handle)[0].device.device_id);
  } else {
    condval_53 = 0;
  }
  int32_t condval_54;
  if (!mhc_project_streams_X_is_null) {
    condval_54 = (((DLTensor*)X_handle)[0].device.device_id);
  } else {
    condval_54 = 0;
  }
  if (!((mhc_project_streams_comb_is_null || (condval_53 == condval_54)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb device_id violates packed ABI constraint");
    return -1;
  }
  int32_t condval_55;
  if (!mhc_project_streams_comb_is_null) {
    condval_55 = (((DLTensor*)comb_handle)[0].device.device_type);
  } else {
    condval_55 = 0;
  }
  if (!((mhc_project_streams_comb_is_null || (condval_55 == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb device_type mismatch, expected cuda");
    return -1;
  }
  if (!(((mhc_project_streams_comb_is_null || (M == 0)) || !(comb == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input comb data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)pre_in_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)pre_in_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)pre_in_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input pre_in dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_56;
  if (!mhc_project_streams_X_is_null) {
    condval_56 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_56 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  if (!((condval_56 == ((int32_t)((int64_t*)mhc_project_streams_pre_in_shape)[0])))) {
    int32_t condval_57;
    if (!mhc_project_streams_X_is_null) {
      condval_57 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
    } else {
      condval_57 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input pre_in shape[0] violates packed ABI constraint", (long long)(condval_57), (long long)(((int32_t)((int64_t*)mhc_project_streams_pre_in_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_project_streams_pre_in_shape)[1]) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input pre_in shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_project_streams_pre_in_shape)[1])), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_58;
  if ((mhc_project_streams_pre_in_strides == NULL)) {
    condval_58 = 1;
  } else {
    condval_58 = ((int32_t)((int64_t*)mhc_project_streams_pre_in_strides)[1]);
  }
  if (!((condval_58 == 1))) {
    int32_t condval_59;
    if ((mhc_project_streams_pre_in_strides == NULL)) {
      condval_59 = 1;
    } else {
      condval_59 = ((int32_t)((int64_t*)mhc_project_streams_pre_in_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input pre_in strides[1] violates packed ABI constraint", (long long)(condval_59), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_60;
  if ((mhc_project_streams_pre_in_strides == NULL)) {
    condval_60 = 1;
  } else {
    condval_60 = ((int32_t)((int64_t*)mhc_project_streams_pre_in_strides)[0]);
  }
  if (!(((condval_60 == 4) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input pre_in strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)pre_in_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input pre_in byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)pre_in_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_61;
  if (!mhc_project_streams_X_is_null) {
    condval_61 = (((DLTensor*)X_handle)[0].device.device_id);
  } else {
    condval_61 = 0;
  }
  if (!(((((DLTensor*)pre_in_handle)[0].device.device_id) == condval_61))) {
    int32_t condval_62;
    if (!mhc_project_streams_X_is_null) {
      condval_62 = (((DLTensor*)X_handle)[0].device.device_id);
    } else {
      condval_62 = 0;
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input pre_in device_id violates packed ABI constraint", (long long)((((DLTensor*)pre_in_handle)[0].device.device_id)), (long long)(condval_62));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)pre_in_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input pre_in device_type mismatch, expected cuda", (long long)((((DLTensor*)pre_in_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(pre_in == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input pre_in data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Fn_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Fn_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Fn_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input Fn dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_project_streams_Fn_shape)[0]) == 24))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Fn shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_project_streams_Fn_shape)[0])), (long long)(24));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_project_streams_Fn_shape)[1]) == 20480))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Fn shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_project_streams_Fn_shape)[1])), (long long)(20480));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_63;
  if ((mhc_project_streams_Fn_strides == NULL)) {
    condval_63 = 1;
  } else {
    condval_63 = ((int32_t)((int64_t*)mhc_project_streams_Fn_strides)[1]);
  }
  if (!((condval_63 == 1))) {
    int32_t condval_64;
    if ((mhc_project_streams_Fn_strides == NULL)) {
      condval_64 = 1;
    } else {
      condval_64 = ((int32_t)((int64_t*)mhc_project_streams_Fn_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Fn strides[1] violates packed ABI constraint", (long long)(condval_64), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_65;
  if ((mhc_project_streams_Fn_strides == NULL)) {
    condval_65 = 1;
  } else {
    condval_65 = ((int32_t)((int64_t*)mhc_project_streams_Fn_strides)[0]);
  }
  if (!((condval_65 == 20480))) {
    int32_t condval_66;
    if ((mhc_project_streams_Fn_strides == NULL)) {
      condval_66 = 1;
    } else {
      condval_66 = ((int32_t)((int64_t*)mhc_project_streams_Fn_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Fn strides[0] violates packed ABI constraint", (long long)(condval_66), (long long)(20480));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Fn_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Fn byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Fn_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_67;
  if (!mhc_project_streams_X_is_null) {
    condval_67 = (((DLTensor*)X_handle)[0].device.device_id);
  } else {
    condval_67 = 0;
  }
  if (!(((((DLTensor*)Fn_handle)[0].device.device_id) == condval_67))) {
    int32_t condval_68;
    if (!mhc_project_streams_X_is_null) {
      condval_68 = (((DLTensor*)X_handle)[0].device.device_id);
    } else {
      condval_68 = 0;
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Fn device_id violates packed ABI constraint", (long long)((((DLTensor*)Fn_handle)[0].device.device_id)), (long long)(condval_68));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Fn_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Fn device_type mismatch, expected cuda", (long long)((((DLTensor*)Fn_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(Fn == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input Fn data pointer is NULL");
    return -1;
  }
  uint8_t condval_69;
  if (!mhc_project_streams_R_out_is_null) {
    condval_69 = (((DLTensor*)R_out_handle)[0].dtype.code);
  } else {
    condval_69 = (uint8_t)4;
  }
  uint8_t condval_70;
  if (!mhc_project_streams_R_out_is_null) {
    condval_70 = (((DLTensor*)R_out_handle)[0].dtype.bits);
  } else {
    condval_70 = (uint8_t)16;
  }
  uint16_t condval_71;
  if (!mhc_project_streams_R_out_is_null) {
    condval_71 = (((DLTensor*)R_out_handle)[0].dtype.lanes);
  } else {
    condval_71 = (uint16_t)1;
  }
  if (!((mhc_project_streams_R_out_is_null || (((condval_69 == (uint8_t)4) && (condval_70 == (uint8_t)16)) && (condval_71 == (uint16_t)1))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R_out dtype mismatch, expected bfloat16");
    return -1;
  }
  int32_t condval_72;
  if (!mhc_project_streams_X_is_null) {
    condval_72 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_72 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  int32_t condval_73;
  if (!mhc_project_streams_R_out_is_null) {
    condval_73 = ((int32_t)((int64_t*)mhc_project_streams_R_out_shape)[0]);
  } else {
    condval_73 = 0;
  }
  if (!((mhc_project_streams_R_out_is_null || (condval_72 == condval_73)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R_out shape[0] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_74;
  if (!mhc_project_streams_R_out_is_null) {
    condval_74 = ((int32_t)((int64_t*)mhc_project_streams_R_out_shape)[1]);
  } else {
    condval_74 = 0;
  }
  if (!((mhc_project_streams_R_out_is_null || (condval_74 == 20480)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R_out shape[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_75;
  if ((mhc_project_streams_R_out_strides == NULL)) {
    condval_75 = 1;
  } else {
    condval_75 = ((int32_t)((int64_t*)mhc_project_streams_R_out_strides)[1]);
  }
  if (!((mhc_project_streams_R_out_is_null || (condval_75 == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R_out strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_76;
  if ((mhc_project_streams_R_out_strides == NULL)) {
    condval_76 = 1;
  } else {
    condval_76 = ((int32_t)((int64_t*)mhc_project_streams_R_out_strides)[0]);
  }
  if (!(((mhc_project_streams_R_out_is_null || (condval_76 == 20480)) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R_out strides[0] violates packed ABI constraint");
    return -1;
  }
  uint64_t condval_77;
  if (!mhc_project_streams_R_out_is_null) {
    condval_77 = (((DLTensor*)R_out_handle)[0].byte_offset);
  } else {
    condval_77 = (uint64_t)0;
  }
  if (!((mhc_project_streams_R_out_is_null || ((uint64_t)0 == condval_77)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R_out byte_offset violates packed ABI constraint");
    return -1;
  }
  int32_t condval_78;
  if (!mhc_project_streams_R_out_is_null) {
    condval_78 = (((DLTensor*)R_out_handle)[0].device.device_id);
  } else {
    condval_78 = 0;
  }
  int32_t condval_79;
  if (!mhc_project_streams_X_is_null) {
    condval_79 = (((DLTensor*)X_handle)[0].device.device_id);
  } else {
    condval_79 = 0;
  }
  if (!((mhc_project_streams_R_out_is_null || (condval_78 == condval_79)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R_out device_id violates packed ABI constraint");
    return -1;
  }
  int32_t condval_80;
  if (!mhc_project_streams_R_out_is_null) {
    condval_80 = (((DLTensor*)R_out_handle)[0].device.device_type);
  } else {
    condval_80 = 0;
  }
  if (!((mhc_project_streams_R_out_is_null || (condval_80 == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R_out device_type mismatch, expected cuda");
    return -1;
  }
  if (!(((mhc_project_streams_R_out_is_null || (M == 0)) || !(R_out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input R_out data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)P_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)P_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)P_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input P dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_project_streams_P_shape)[0]) == 40))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input P shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_project_streams_P_shape)[0])), (long long)(40));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_81;
  if (!mhc_project_streams_X_is_null) {
    condval_81 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_81 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  if (!((condval_81 == ((int32_t)((int64_t*)mhc_project_streams_P_shape)[1])))) {
    int32_t condval_82;
    if (!mhc_project_streams_X_is_null) {
      condval_82 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
    } else {
      condval_82 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input P shape[1] violates packed ABI constraint", (long long)(condval_82), (long long)(((int32_t)((int64_t*)mhc_project_streams_P_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_project_streams_P_shape)[2]) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input P shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_project_streams_P_shape)[2])), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_project_streams_P_shape)[3]) == 24))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input P shape[3] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_project_streams_P_shape)[3])), (long long)(24));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_83;
  if ((mhc_project_streams_P_strides == NULL)) {
    condval_83 = 1;
  } else {
    condval_83 = ((int32_t)((int64_t*)mhc_project_streams_P_strides)[3]);
  }
  if (!((condval_83 == 1))) {
    int32_t condval_84;
    if ((mhc_project_streams_P_strides == NULL)) {
      condval_84 = 1;
    } else {
      condval_84 = ((int32_t)((int64_t*)mhc_project_streams_P_strides)[3]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input P strides[3] violates packed ABI constraint", (long long)(condval_84), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_85;
  if ((mhc_project_streams_P_strides == NULL)) {
    condval_85 = 1;
  } else {
    condval_85 = ((int32_t)((int64_t*)mhc_project_streams_P_strides)[1]);
  }
  if (!(((condval_85 == 24) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input P strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_86;
  if ((mhc_project_streams_P_strides == NULL)) {
    condval_86 = 1;
  } else {
    condval_86 = ((int32_t)((int64_t*)mhc_project_streams_P_strides)[0]);
  }
  if (!((((M * 24) == condval_86) || (M == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input P strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)P_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input P byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)P_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_87;
  if (!mhc_project_streams_X_is_null) {
    condval_87 = (((DLTensor*)X_handle)[0].device.device_id);
  } else {
    condval_87 = 0;
  }
  if (!(((((DLTensor*)P_handle)[0].device.device_id) == condval_87))) {
    int32_t condval_88;
    if (!mhc_project_streams_X_is_null) {
      condval_88 = (((DLTensor*)X_handle)[0].device.device_id);
    } else {
      condval_88 = 0;
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input P device_id violates packed ABI constraint", (long long)((((DLTensor*)P_handle)[0].device.device_id)), (long long)(condval_88));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)P_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input P device_type mismatch, expected cuda", (long long)((((DLTensor*)P_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(P == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input P data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)S_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)S_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)S_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input S dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_project_streams_S_shape)[0]) == 40))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input S shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_project_streams_S_shape)[0])), (long long)(40));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_89;
  if (!mhc_project_streams_X_is_null) {
    condval_89 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_89 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  if (!((condval_89 == ((int32_t)((int64_t*)mhc_project_streams_S_shape)[1])))) {
    int32_t condval_90;
    if (!mhc_project_streams_X_is_null) {
      condval_90 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
    } else {
      condval_90 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input S shape[1] violates packed ABI constraint", (long long)(condval_90), (long long)(((int32_t)((int64_t*)mhc_project_streams_S_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_project_streams_S_shape)[2]) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input S shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_project_streams_S_shape)[2])), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_91;
  if ((mhc_project_streams_S_strides == NULL)) {
    condval_91 = 1;
  } else {
    condval_91 = ((int32_t)((int64_t*)mhc_project_streams_S_strides)[1]);
  }
  if (!(((condval_91 == 1) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input S strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_92;
  if (!mhc_project_streams_X_is_null) {
    condval_92 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_92 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  int32_t condval_93;
  if ((mhc_project_streams_S_strides == NULL)) {
    condval_93 = 1;
  } else {
    condval_93 = ((int32_t)((int64_t*)mhc_project_streams_S_strides)[0]);
  }
  int32_t condval_94;
  if (!mhc_project_streams_X_is_null) {
    condval_94 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_94 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  if (!(((condval_92 == condval_93) || (condval_94 == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input S strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)S_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input S byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)S_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_95;
  if (!mhc_project_streams_X_is_null) {
    condval_95 = (((DLTensor*)X_handle)[0].device.device_id);
  } else {
    condval_95 = 0;
  }
  if (!(((((DLTensor*)S_handle)[0].device.device_id) == condval_95))) {
    int32_t condval_96;
    if (!mhc_project_streams_X_is_null) {
      condval_96 = (((DLTensor*)X_handle)[0].device.device_id);
    } else {
      condval_96 = 0;
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input S device_id violates packed ABI constraint", (long long)((((DLTensor*)S_handle)[0].device.device_id)), (long long)(condval_96));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)S_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input S device_type mismatch, expected cuda", (long long)((((DLTensor*)S_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(S == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input S data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)C_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)C_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)C_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input C dtype mismatch, expected bfloat16");
    return -1;
  }
  int32_t condval_97;
  if (!mhc_project_streams_X_is_null) {
    condval_97 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_97 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  if (!((condval_97 == ((int32_t)((int64_t*)mhc_project_streams_C_shape)[0])))) {
    int32_t condval_98;
    if (!mhc_project_streams_X_is_null) {
      condval_98 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
    } else {
      condval_98 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input C shape[0] violates packed ABI constraint", (long long)(condval_98), (long long)(((int32_t)((int64_t*)mhc_project_streams_C_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_project_streams_C_shape)[1]) == 5120))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input C shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_project_streams_C_shape)[1])), (long long)(5120));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_99;
  if ((mhc_project_streams_C_strides == NULL)) {
    condval_99 = 1;
  } else {
    condval_99 = ((int32_t)((int64_t*)mhc_project_streams_C_strides)[1]);
  }
  if (!((condval_99 == 1))) {
    int32_t condval_100;
    if ((mhc_project_streams_C_strides == NULL)) {
      condval_100 = 1;
    } else {
      condval_100 = ((int32_t)((int64_t*)mhc_project_streams_C_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input C strides[1] violates packed ABI constraint", (long long)(condval_100), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_101;
  if ((mhc_project_streams_C_strides == NULL)) {
    condval_101 = 1;
  } else {
    condval_101 = ((int32_t)((int64_t*)mhc_project_streams_C_strides)[0]);
  }
  if (!(((condval_101 == 5120) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input C strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)C_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input C byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)C_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_102;
  if (!mhc_project_streams_X_is_null) {
    condval_102 = (((DLTensor*)X_handle)[0].device.device_id);
  } else {
    condval_102 = 0;
  }
  if (!(((((DLTensor*)C_handle)[0].device.device_id) == condval_102))) {
    int32_t condval_103;
    if (!mhc_project_streams_X_is_null) {
      condval_103 = (((DLTensor*)X_handle)[0].device.device_id);
    } else {
      condval_103 = 0;
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input C device_id violates packed ABI constraint", (long long)((((DLTensor*)C_handle)[0].device.device_id)), (long long)(condval_103));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)C_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input C device_type mismatch, expected cuda", (long long)((((DLTensor*)C_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(C == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input C data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Q_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Q_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Q_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input Q dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_project_streams_Q_shape)[0]) == 40))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Q shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_project_streams_Q_shape)[0])), (long long)(40));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_104;
  if (!mhc_project_streams_X_is_null) {
    condval_104 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_104 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  if (!((condval_104 == ((int32_t)((int64_t*)mhc_project_streams_Q_shape)[1])))) {
    int32_t condval_105;
    if (!mhc_project_streams_X_is_null) {
      condval_105 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
    } else {
      condval_105 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Q shape[1] violates packed ABI constraint", (long long)(condval_105), (long long)(((int32_t)((int64_t*)mhc_project_streams_Q_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_106;
  if ((mhc_project_streams_Q_strides == NULL)) {
    condval_106 = 1;
  } else {
    condval_106 = ((int32_t)((int64_t*)mhc_project_streams_Q_strides)[1]);
  }
  if (!(((condval_106 == 1) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input Q strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_107;
  if (!mhc_project_streams_X_is_null) {
    condval_107 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_107 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  int32_t condval_108;
  if ((mhc_project_streams_Q_strides == NULL)) {
    condval_108 = 1;
  } else {
    condval_108 = ((int32_t)((int64_t*)mhc_project_streams_Q_strides)[0]);
  }
  int32_t condval_109;
  if (!mhc_project_streams_X_is_null) {
    condval_109 = ((int32_t)((int64_t*)mhc_project_streams_X_shape)[1]);
  } else {
    condval_109 = ((int32_t)((int64_t*)mhc_project_streams_R_shape)[0]);
  }
  if (!(((condval_107 == condval_108) || (condval_109 == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input Q strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Q_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Q byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Q_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_110;
  if (!mhc_project_streams_X_is_null) {
    condval_110 = (((DLTensor*)X_handle)[0].device.device_id);
  } else {
    condval_110 = 0;
  }
  if (!(((((DLTensor*)Q_handle)[0].device.device_id) == condval_110))) {
    int32_t condval_111;
    if (!mhc_project_streams_X_is_null) {
      condval_111 = (((DLTensor*)X_handle)[0].device.device_id);
    } else {
      condval_111 = 0;
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Q device_id violates packed ABI constraint", (long long)((((DLTensor*)Q_handle)[0].device.device_id)), (long long)(condval_111));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Q_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_project_streams input Q device_type mismatch, expected cuda", (long long)((((DLTensor*)Q_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(Q == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_project_streams input Q data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (C == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = C;
  if (Fn == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = Fn;
  if (P == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = P;
  if (Q == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = Q;
  if (R == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = R;
  if (S == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = S;
  if (pre_in == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = pre_in;
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)40);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)((M + 15) >> 4));
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)57344);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = (int64_t)0;
  if (mhc_project_streams_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "mhc_project_streams_kernel", &mhc_project_streams_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(mhc_project_streams_kernel_packed, (TVMFFIAny*) stack_ffi_any, 14, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_mhc_project_streams(self, args, num_args, result);
}
