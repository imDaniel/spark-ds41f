// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* mhc_finalize_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_mhc_finalize(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_mhc_finalize(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[18];
  void* stack_ffi_any = stack;
  if (!((num_args == 11))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "mhc_finalize: num_args should be 11", (long long)(num_args), (long long)(11));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_finalize: args pointer is NULL");
    return -1;
  }
  int32_t P_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((P_handle_type_index == 0) || (P_handle_type_index == 4)) || (P_handle_type_index == 7)) || (64 <= P_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input P expected pointer or tensor handle");
    return -1;
  }
  int32_t S_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((S_handle_type_index == 0) || (S_handle_type_index == 4)) || (S_handle_type_index == 7)) || (64 <= S_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input S expected pointer or tensor handle");
    return -1;
  }
  int32_t C_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((C_handle_type_index == 0) || (C_handle_type_index == 4)) || (C_handle_type_index == 7)) || (64 <= C_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input C expected pointer or tensor handle");
    return -1;
  }
  int32_t Q_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((Q_handle_type_index == 0) || (Q_handle_type_index == 4)) || (Q_handle_type_index == 7)) || (64 <= Q_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input Q expected pointer or tensor handle");
    return -1;
  }
  int32_t scale_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((scale_handle_type_index == 0) || (scale_handle_type_index == 4)) || (scale_handle_type_index == 7)) || (64 <= scale_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input scale expected pointer or tensor handle");
    return -1;
  }
  int32_t base_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((base_handle_type_index == 0) || (base_handle_type_index == 4)) || (base_handle_type_index == 7)) || (64 <= base_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input base expected pointer or tensor handle");
    return -1;
  }
  int32_t weight_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((weight_handle_type_index == 0) || (weight_handle_type_index == 4)) || (weight_handle_type_index == 7)) || (64 <= weight_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input weight expected pointer or tensor handle");
    return -1;
  }
  int32_t post_handle_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((((post_handle_type_index == 0) || (post_handle_type_index == 4)) || (post_handle_type_index == 7)) || (64 <= post_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input post expected pointer or tensor handle");
    return -1;
  }
  int32_t comb_handle_type_index = (((TVMFFIAny*)args)[8].type_index);
  if (!(((((comb_handle_type_index == 0) || (comb_handle_type_index == 4)) || (comb_handle_type_index == 7)) || (64 <= comb_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input comb expected pointer or tensor handle");
    return -1;
  }
  int32_t pre_out_handle_type_index = (((TVMFFIAny*)args)[9].type_index);
  if (!(((((pre_out_handle_type_index == 0) || (pre_out_handle_type_index == 4)) || (pre_out_handle_type_index == 7)) || (64 <= pre_out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input pre_out expected pointer or tensor handle");
    return -1;
  }
  int32_t y_handle_type_index = (((TVMFFIAny*)args)[10].type_index);
  if (!(((((y_handle_type_index == 0) || (y_handle_type_index == 4)) || (y_handle_type_index == 7)) || (64 <= y_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input y expected pointer or tensor handle");
    return -1;
  }
  void* P_handle = ((P_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* S_handle = ((S_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* C_handle = ((C_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* Q_handle = ((Q_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* scale_handle = ((scale_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* base_handle = ((base_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* weight_handle = ((weight_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  void* post_handle = ((post_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[7].v_ptr) + 24)) : (((TVMFFIAny*)args)[7].v_ptr));
  void* comb_handle = ((comb_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[8].v_ptr) + 24)) : (((TVMFFIAny*)args)[8].v_ptr));
  void* pre_out_handle = ((pre_out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[9].v_ptr) + 24)) : (((TVMFFIAny*)args)[9].v_ptr));
  void* y_handle = ((y_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[10].v_ptr) + 24)) : (((TVMFFIAny*)args)[10].v_ptr));
  bool mhc_finalize_P_is_null = (P_handle == NULL);
  if (!(!mhc_finalize_P_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_finalize.P is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_finalize_S_is_null = (S_handle == NULL);
  if (!(!mhc_finalize_S_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_finalize.S is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_finalize_C_is_null = (C_handle == NULL);
  if (!(!mhc_finalize_C_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_finalize.C is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_finalize_Q_is_null = (Q_handle == NULL);
  if (!(!mhc_finalize_Q_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_finalize.Q is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_finalize_scale_is_null = (scale_handle == NULL);
  if (!(!mhc_finalize_scale_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_finalize.scale is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_finalize_base_is_null = (base_handle == NULL);
  if (!(!mhc_finalize_base_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_finalize.base is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_finalize_weight_is_null = (weight_handle == NULL);
  if (!(!mhc_finalize_weight_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_finalize.weight is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_finalize_post_is_null = (post_handle == NULL);
  if (!(!mhc_finalize_post_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_finalize.post is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_finalize_comb_is_null = (comb_handle == NULL);
  if (!(!mhc_finalize_comb_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_finalize.comb is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_finalize_pre_out_is_null = (pre_out_handle == NULL);
  if (!(!mhc_finalize_pre_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_finalize.pre_out is expected to have non-NULL pointer");
    return -1;
  }
  bool mhc_finalize_y_is_null = (y_handle == NULL);
  if (!(!mhc_finalize_y_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "mhc_finalize.y is expected to have non-NULL pointer");
    return -1;
  }
  void* mhc_finalize_P_shape = (((DLTensor*)P_handle)[0].shape);
  void* mhc_finalize_S_shape = (((DLTensor*)S_handle)[0].shape);
  void* mhc_finalize_C_shape = (((DLTensor*)C_handle)[0].shape);
  void* mhc_finalize_Q_shape = (((DLTensor*)Q_handle)[0].shape);
  void* mhc_finalize_scale_shape = (((DLTensor*)scale_handle)[0].shape);
  void* mhc_finalize_base_shape = (((DLTensor*)base_handle)[0].shape);
  void* mhc_finalize_weight_shape = (((DLTensor*)weight_handle)[0].shape);
  void* mhc_finalize_post_shape = (((DLTensor*)post_handle)[0].shape);
  void* mhc_finalize_comb_shape = (((DLTensor*)comb_handle)[0].shape);
  void* mhc_finalize_pre_out_shape = (((DLTensor*)pre_out_handle)[0].shape);
  void* mhc_finalize_y_shape = (((DLTensor*)y_handle)[0].shape);
  if (!(((((DLTensor*)P_handle)[0].ndim) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input P ndim mismatch, expected 4", (long long)((((DLTensor*)P_handle)[0].ndim)), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable M requires at least one non-null buffer among: mhc_finalize.P, mhc_finalize.S, mhc_finalize.C, mhc_finalize.Q, mhc_finalize.post, mhc_finalize.comb, mhc_finalize.pre_out, mhc_finalize.y");
    return -1;
  }
  int32_t M = ((int32_t)((int64_t*)mhc_finalize_P_shape)[1]);
  void* mhc_finalize_P_strides = (((DLTensor*)P_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)P_handle)[0].device.device_id);
  void* P = (((DLTensor*)P_handle)[0].data);
  if (!(((((DLTensor*)S_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input S ndim mismatch, expected 3", (long long)((((DLTensor*)S_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_finalize_S_strides = (((DLTensor*)S_handle)[0].strides);
  void* S = (((DLTensor*)S_handle)[0].data);
  if (!(((((DLTensor*)C_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input C ndim mismatch, expected 2", (long long)((((DLTensor*)C_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_finalize_C_strides = (((DLTensor*)C_handle)[0].strides);
  void* C = (((DLTensor*)C_handle)[0].data);
  if (!(((((DLTensor*)Q_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input Q ndim mismatch, expected 2", (long long)((((DLTensor*)Q_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_finalize_Q_strides = (((DLTensor*)Q_handle)[0].strides);
  void* Q = (((DLTensor*)Q_handle)[0].data);
  if (!(((((DLTensor*)scale_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input scale ndim mismatch, expected 1", (long long)((((DLTensor*)scale_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_finalize_scale_strides = (((DLTensor*)scale_handle)[0].strides);
  void* scale = (((DLTensor*)scale_handle)[0].data);
  if (!(((((DLTensor*)base_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input base ndim mismatch, expected 1", (long long)((((DLTensor*)base_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_finalize_base_strides = (((DLTensor*)base_handle)[0].strides);
  void* base = (((DLTensor*)base_handle)[0].data);
  if (!(((((DLTensor*)weight_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input weight ndim mismatch, expected 1", (long long)((((DLTensor*)weight_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_finalize_weight_strides = (((DLTensor*)weight_handle)[0].strides);
  void* weight = (((DLTensor*)weight_handle)[0].data);
  if (!(((((DLTensor*)post_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input post ndim mismatch, expected 2", (long long)((((DLTensor*)post_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_finalize_post_strides = (((DLTensor*)post_handle)[0].strides);
  void* post = (((DLTensor*)post_handle)[0].data);
  if (!(((((DLTensor*)comb_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input comb ndim mismatch, expected 3", (long long)((((DLTensor*)comb_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_finalize_comb_strides = (((DLTensor*)comb_handle)[0].strides);
  void* comb = (((DLTensor*)comb_handle)[0].data);
  if (!(((((DLTensor*)pre_out_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input pre_out ndim mismatch, expected 2", (long long)((((DLTensor*)pre_out_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_finalize_pre_out_strides = (((DLTensor*)pre_out_handle)[0].strides);
  void* pre_out = (((DLTensor*)pre_out_handle)[0].data);
  if (!(((((DLTensor*)y_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input y ndim mismatch, expected 2", (long long)((((DLTensor*)y_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* mhc_finalize_y_strides = (((DLTensor*)y_handle)[0].strides);
  void* y = (((DLTensor*)y_handle)[0].data);
  if (!(((((((DLTensor*)P_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)P_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)P_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input P dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_P_shape)[0]) == 40))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input P shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_P_shape)[0])), (long long)(40));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_P_shape)[2]) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input P shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_P_shape)[2])), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_P_shape)[3]) == 24))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input P shape[3] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_P_shape)[3])), (long long)(24));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((mhc_finalize_P_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)mhc_finalize_P_strides)[3]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((mhc_finalize_P_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)mhc_finalize_P_strides)[3]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input P strides[3] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((mhc_finalize_P_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)mhc_finalize_P_strides)[1]);
  }
  if (!(((condval_2 == 24) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input P strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_3;
  if ((mhc_finalize_P_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)mhc_finalize_P_strides)[0]);
  }
  if (!((((M * 24) == condval_3) || (M == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input P strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)P_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input P byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)P_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)P_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input P device_type mismatch, expected cuda", (long long)((((DLTensor*)P_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(P == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input P data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)S_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)S_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)S_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input S dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_S_shape)[0]) == 40))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input S shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_S_shape)[0])), (long long)(40));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_P_shape)[1]) == ((int32_t)((int64_t*)mhc_finalize_S_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input S shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_P_shape)[1])), (long long)(((int32_t)((int64_t*)mhc_finalize_S_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_S_shape)[2]) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input S shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_S_shape)[2])), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_4;
  if ((mhc_finalize_S_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)mhc_finalize_S_strides)[1]);
  }
  if (!(((condval_4 == 1) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input S strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_5;
  if ((mhc_finalize_S_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)mhc_finalize_S_strides)[0]);
  }
  if (!(((((int32_t)((int64_t*)mhc_finalize_P_shape)[1]) == condval_5) || (((int32_t)((int64_t*)mhc_finalize_P_shape)[1]) == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input S strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)S_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input S byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)S_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)S_handle)[0].device.device_id) == (((DLTensor*)P_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input S device_id violates packed ABI constraint", (long long)((((DLTensor*)S_handle)[0].device.device_id)), (long long)((((DLTensor*)P_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)S_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input S device_type mismatch, expected cuda", (long long)((((DLTensor*)S_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(S == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input S data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)C_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)C_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)C_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input C dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_P_shape)[1]) == ((int32_t)((int64_t*)mhc_finalize_C_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input C shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_P_shape)[1])), (long long)(((int32_t)((int64_t*)mhc_finalize_C_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_C_shape)[1]) == 5120))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input C shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_C_shape)[1])), (long long)(5120));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((mhc_finalize_C_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)mhc_finalize_C_strides)[1]);
  }
  if (!((condval_6 == 1))) {
    int32_t condval_7;
    if ((mhc_finalize_C_strides == NULL)) {
      condval_7 = 1;
    } else {
      condval_7 = ((int32_t)((int64_t*)mhc_finalize_C_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input C strides[1] violates packed ABI constraint", (long long)(condval_7), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((mhc_finalize_C_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)mhc_finalize_C_strides)[0]);
  }
  if (!(((condval_8 == 5120) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input C strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)C_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input C byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)C_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)C_handle)[0].device.device_id) == (((DLTensor*)P_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input C device_id violates packed ABI constraint", (long long)((((DLTensor*)C_handle)[0].device.device_id)), (long long)((((DLTensor*)P_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)C_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input C device_type mismatch, expected cuda", (long long)((((DLTensor*)C_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(C == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input C data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Q_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Q_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Q_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input Q dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_Q_shape)[0]) == 40))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input Q shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_Q_shape)[0])), (long long)(40));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_P_shape)[1]) == ((int32_t)((int64_t*)mhc_finalize_Q_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input Q shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_P_shape)[1])), (long long)(((int32_t)((int64_t*)mhc_finalize_Q_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((mhc_finalize_Q_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)mhc_finalize_Q_strides)[1]);
  }
  if (!(((condval_9 == 1) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input Q strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_10;
  if ((mhc_finalize_Q_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)mhc_finalize_Q_strides)[0]);
  }
  if (!(((((int32_t)((int64_t*)mhc_finalize_P_shape)[1]) == condval_10) || (((int32_t)((int64_t*)mhc_finalize_P_shape)[1]) == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input Q strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Q_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input Q byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Q_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Q_handle)[0].device.device_id) == (((DLTensor*)P_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input Q device_id violates packed ABI constraint", (long long)((((DLTensor*)Q_handle)[0].device.device_id)), (long long)((((DLTensor*)P_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Q_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input Q device_type mismatch, expected cuda", (long long)((((DLTensor*)Q_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(Q == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input Q data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)scale_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)scale_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)scale_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input scale dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_scale_shape)[0]) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input scale shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_scale_shape)[0])), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_11;
  if ((mhc_finalize_scale_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)mhc_finalize_scale_strides)[0]);
  }
  if (!((condval_11 == 1))) {
    int32_t condval_12;
    if ((mhc_finalize_scale_strides == NULL)) {
      condval_12 = 1;
    } else {
      condval_12 = ((int32_t)((int64_t*)mhc_finalize_scale_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input scale strides[0] violates packed ABI constraint", (long long)(condval_12), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)scale_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input scale byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)scale_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)scale_handle)[0].device.device_id) == (((DLTensor*)P_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input scale device_id violates packed ABI constraint", (long long)((((DLTensor*)scale_handle)[0].device.device_id)), (long long)((((DLTensor*)P_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)scale_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input scale device_type mismatch, expected cuda", (long long)((((DLTensor*)scale_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(scale == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input scale data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)base_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)base_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)base_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input base dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_base_shape)[0]) == 24))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input base shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_base_shape)[0])), (long long)(24));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_13;
  if ((mhc_finalize_base_strides == NULL)) {
    condval_13 = 1;
  } else {
    condval_13 = ((int32_t)((int64_t*)mhc_finalize_base_strides)[0]);
  }
  if (!((condval_13 == 1))) {
    int32_t condval_14;
    if ((mhc_finalize_base_strides == NULL)) {
      condval_14 = 1;
    } else {
      condval_14 = ((int32_t)((int64_t*)mhc_finalize_base_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input base strides[0] violates packed ABI constraint", (long long)(condval_14), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)base_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input base byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)base_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)base_handle)[0].device.device_id) == (((DLTensor*)P_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input base device_id violates packed ABI constraint", (long long)((((DLTensor*)base_handle)[0].device.device_id)), (long long)((((DLTensor*)P_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)base_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input base device_type mismatch, expected cuda", (long long)((((DLTensor*)base_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(base == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input base data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)weight_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)weight_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)weight_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input weight dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_weight_shape)[0]) == 5120))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input weight shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_weight_shape)[0])), (long long)(5120));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_15;
  if ((mhc_finalize_weight_strides == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)mhc_finalize_weight_strides)[0]);
  }
  if (!((condval_15 == 1))) {
    int32_t condval_16;
    if ((mhc_finalize_weight_strides == NULL)) {
      condval_16 = 1;
    } else {
      condval_16 = ((int32_t)((int64_t*)mhc_finalize_weight_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input weight strides[0] violates packed ABI constraint", (long long)(condval_16), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)weight_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input weight byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)weight_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)weight_handle)[0].device.device_id) == (((DLTensor*)P_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input weight device_id violates packed ABI constraint", (long long)((((DLTensor*)weight_handle)[0].device.device_id)), (long long)((((DLTensor*)P_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)weight_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input weight device_type mismatch, expected cuda", (long long)((((DLTensor*)weight_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(weight == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input weight data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)post_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)post_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)post_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input post dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_P_shape)[1]) == ((int32_t)((int64_t*)mhc_finalize_post_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input post shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_P_shape)[1])), (long long)(((int32_t)((int64_t*)mhc_finalize_post_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_post_shape)[1]) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input post shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_post_shape)[1])), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_17;
  if ((mhc_finalize_post_strides == NULL)) {
    condval_17 = 1;
  } else {
    condval_17 = ((int32_t)((int64_t*)mhc_finalize_post_strides)[1]);
  }
  if (!((condval_17 == 1))) {
    int32_t condval_18;
    if ((mhc_finalize_post_strides == NULL)) {
      condval_18 = 1;
    } else {
      condval_18 = ((int32_t)((int64_t*)mhc_finalize_post_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input post strides[1] violates packed ABI constraint", (long long)(condval_18), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_19;
  if ((mhc_finalize_post_strides == NULL)) {
    condval_19 = 1;
  } else {
    condval_19 = ((int32_t)((int64_t*)mhc_finalize_post_strides)[0]);
  }
  if (!(((condval_19 == 4) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input post strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)post_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input post byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)post_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)post_handle)[0].device.device_id) == (((DLTensor*)P_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input post device_id violates packed ABI constraint", (long long)((((DLTensor*)post_handle)[0].device.device_id)), (long long)((((DLTensor*)P_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)post_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input post device_type mismatch, expected cuda", (long long)((((DLTensor*)post_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(post == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input post data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)comb_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)comb_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)comb_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input comb dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_P_shape)[1]) == ((int32_t)((int64_t*)mhc_finalize_comb_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input comb shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_P_shape)[1])), (long long)(((int32_t)((int64_t*)mhc_finalize_comb_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_comb_shape)[1]) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input comb shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_comb_shape)[1])), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_comb_shape)[2]) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input comb shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_comb_shape)[2])), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_20;
  if ((mhc_finalize_comb_strides == NULL)) {
    condval_20 = 1;
  } else {
    condval_20 = ((int32_t)((int64_t*)mhc_finalize_comb_strides)[2]);
  }
  if (!((condval_20 == 1))) {
    int32_t condval_21;
    if ((mhc_finalize_comb_strides == NULL)) {
      condval_21 = 1;
    } else {
      condval_21 = ((int32_t)((int64_t*)mhc_finalize_comb_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input comb strides[2] violates packed ABI constraint", (long long)(condval_21), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_22;
  if ((mhc_finalize_comb_strides == NULL)) {
    condval_22 = 1;
  } else {
    condval_22 = ((int32_t)((int64_t*)mhc_finalize_comb_strides)[1]);
  }
  if (!((condval_22 == 4))) {
    int32_t condval_23;
    if ((mhc_finalize_comb_strides == NULL)) {
      condval_23 = 1;
    } else {
      condval_23 = ((int32_t)((int64_t*)mhc_finalize_comb_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input comb strides[1] violates packed ABI constraint", (long long)(condval_23), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_24;
  if ((mhc_finalize_comb_strides == NULL)) {
    condval_24 = 1;
  } else {
    condval_24 = ((int32_t)((int64_t*)mhc_finalize_comb_strides)[0]);
  }
  if (!(((condval_24 == 16) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input comb strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)comb_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input comb byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)comb_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)comb_handle)[0].device.device_id) == (((DLTensor*)P_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input comb device_id violates packed ABI constraint", (long long)((((DLTensor*)comb_handle)[0].device.device_id)), (long long)((((DLTensor*)P_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)comb_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input comb device_type mismatch, expected cuda", (long long)((((DLTensor*)comb_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(comb == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input comb data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)pre_out_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)pre_out_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)pre_out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input pre_out dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_P_shape)[1]) == ((int32_t)((int64_t*)mhc_finalize_pre_out_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input pre_out shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_P_shape)[1])), (long long)(((int32_t)((int64_t*)mhc_finalize_pre_out_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_pre_out_shape)[1]) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input pre_out shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_pre_out_shape)[1])), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_25;
  if ((mhc_finalize_pre_out_strides == NULL)) {
    condval_25 = 1;
  } else {
    condval_25 = ((int32_t)((int64_t*)mhc_finalize_pre_out_strides)[1]);
  }
  if (!((condval_25 == 1))) {
    int32_t condval_26;
    if ((mhc_finalize_pre_out_strides == NULL)) {
      condval_26 = 1;
    } else {
      condval_26 = ((int32_t)((int64_t*)mhc_finalize_pre_out_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input pre_out strides[1] violates packed ABI constraint", (long long)(condval_26), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_27;
  if ((mhc_finalize_pre_out_strides == NULL)) {
    condval_27 = 1;
  } else {
    condval_27 = ((int32_t)((int64_t*)mhc_finalize_pre_out_strides)[0]);
  }
  if (!(((condval_27 == 4) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input pre_out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)pre_out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input pre_out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)pre_out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)pre_out_handle)[0].device.device_id) == (((DLTensor*)P_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input pre_out device_id violates packed ABI constraint", (long long)((((DLTensor*)pre_out_handle)[0].device.device_id)), (long long)((((DLTensor*)P_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)pre_out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input pre_out device_type mismatch, expected cuda", (long long)((((DLTensor*)pre_out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(pre_out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input pre_out data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)y_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)y_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)y_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input y dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_P_shape)[1]) == ((int32_t)((int64_t*)mhc_finalize_y_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input y shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_P_shape)[1])), (long long)(((int32_t)((int64_t*)mhc_finalize_y_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)mhc_finalize_y_shape)[1]) == 5120))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input y shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)mhc_finalize_y_shape)[1])), (long long)(5120));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_28;
  if ((mhc_finalize_y_strides == NULL)) {
    condval_28 = 1;
  } else {
    condval_28 = ((int32_t)((int64_t*)mhc_finalize_y_strides)[1]);
  }
  if (!((condval_28 == 1))) {
    int32_t condval_29;
    if ((mhc_finalize_y_strides == NULL)) {
      condval_29 = 1;
    } else {
      condval_29 = ((int32_t)((int64_t*)mhc_finalize_y_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input y strides[1] violates packed ABI constraint", (long long)(condval_29), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_30;
  if ((mhc_finalize_y_strides == NULL)) {
    condval_30 = 1;
  } else {
    condval_30 = ((int32_t)((int64_t*)mhc_finalize_y_strides)[0]);
  }
  if (!(((condval_30 == 5120) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input y strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)y_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input y byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)y_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)y_handle)[0].device.device_id) == (((DLTensor*)P_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input y device_id violates packed ABI constraint", (long long)((((DLTensor*)y_handle)[0].device.device_id)), (long long)((((DLTensor*)P_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)y_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel mhc_finalize input y device_type mismatch, expected cuda", (long long)((((DLTensor*)y_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(y == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel mhc_finalize input y data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (C == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = C;
  if (P == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = P;
  if (Q == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = Q;
  if (S == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = S;
  if (base == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = base;
  if (comb == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = comb;
  if (post == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = post;
  if (pre_out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_ptr) = pre_out;
  if (scale == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_ptr) = scale;
  if (weight == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_ptr) = weight;
  if (y == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_ptr) = y;
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[15].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[15].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[15].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[16].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[16].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].v_int64) = ((int64_t)96);
  (((TVMFFIAny*)stack_ffi_any)[17].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[17].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[17].v_int64) = (int64_t)0;
  if (mhc_finalize_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "mhc_finalize_kernel", &mhc_finalize_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(mhc_finalize_kernel_packed, (TVMFFIAny*) stack_ffi_any, 17, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_mhc_finalize(self, args, num_args, result);
}
